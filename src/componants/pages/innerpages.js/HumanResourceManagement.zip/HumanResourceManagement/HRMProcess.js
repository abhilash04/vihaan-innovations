import React from "react";
import { Box, Grid, Typography, Container } from "@mui/material";
import FactoryIcon from "@mui/icons-material/Factory";
import LocalHospitalIcon from "@mui/icons-material/LocalHospital";
import SchoolIcon from "@mui/icons-material/School";
import DesktopWindowsIcon from "@mui/icons-material/DesktopWindows";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";

const modules = [
  {
    title: "Analysis",
    desc: "Analyze business requirements, existing systems, and operational workflows to design the right HRM solution."
  },
  {
    title: "Customization",
    desc: "Customize modules and HRM integrations according to business needs and employee workflows."
  },
  {
    title: "Engineering",
    desc: "Develop scalable HRM applications with robust architecture and secure data management."
  },
  {
    title: "Testing",
    desc: "Perform detailed testing and validation to ensure performance, security, and reliability."
  }
];

const HRMProcess = () => {
  return (
    <Box
      sx={{
        background: "linear-gradient(45deg, #03228f, #93c0f8)",
        color: "#000",
        py: { xs: 4, md: 6 }
      }}
    >
      <Container maxWidth="lg">

        {/* Title */}
        <Box textAlign="center" mb={6}>
          <Typography
            variant="overline"
            sx={{ letterSpacing: 2, color: "#00bcd4" }}
          >
            OUR HRM DEVELOPMENT PROCESS
          </Typography>

          <Typography
            variant="h3"
            fontWeight="bold"
            sx={{ 
              mt: 1, 
              fontSize: { xs: 28, sm: 36, md: 42 },
              color: "#000"
            }}
          >
            Modules in Using HRM Systems
          </Typography>
        </Box>

        {/* Timeline */}
        <Grid container spacing={1} alignItems="center">

          {/* Left side */}
          <Grid item xs={12} md={5}>
            <Box textAlign={{ xs: "center", md: "right" }} mb={4}>
              <Typography variant="h5" fontWeight="bold" sx={{ fontSize: { xs: 20, md: 24 }, color: "#ffb347" }}>
                {modules[0].title}
              </Typography>
              <Typography variant="body1" sx={{ opacity: 0.9, fontSize: { xs: 14, md: 16 } }}>
                {modules[0].desc}
              </Typography>
            </Box>

            <Box textAlign={{ xs: "center", md: "right" }}>
              <Typography variant="h5" fontWeight="bold" sx={{ fontSize: { xs: 20, md: 24 }, color: "#ffb347" }}>
                {modules[2].title}
              </Typography>
              <Typography variant="body1" sx={{ opacity: 0.9, fontSize: { xs: 14, md: 16 } }}>
                {modules[2].desc}
              </Typography>
            </Box>
          </Grid>

          {/* Center line */}
          <Grid item xs={12} md={2} sx={{ display: { xs: "none", md: "flex" }, justifyContent: "center" }}>
            <Box
              sx={{
                width: "2px",
                height: "220px",
              background: "linear-gradient(#03228f,#4e95ed)",
                position: "relative"
              }}
            >
              <Box
                sx={{
                  width: 14,
                  height: 14,
                  background: "#ffb347",
                  borderRadius: "50%",
                  position: "absolute",
                  top: 40,
                  left: -6,
                  boxShadow: "0 0 10px #ffb347",
                  animation: "shine 2s infinite",
                  "@keyframes shine": {
                    "0%": { boxShadow: "0 0 10px #ffb347" },
                    "50%": { boxShadow: "0 0 20px #ffb347, 0 0 30px #ffb347" },
                    "100%": { boxShadow: "0 0 10px #ffb347" }
                  }
                }}
              />

              <Box
                sx={{
                  width: 14,
                  height: 14,
                  background: "#ffb347",
                  borderRadius: "50%",
                  position: "absolute",
                  bottom: 40,
                  left: -6,
                  boxShadow: "0 0 10px #ffb347",
                  animation: "shine 2s infinite 1s"
                }}
              />
            </Box>
          </Grid>

          {/* Right side */}
          <Grid item xs={12} md={5}>
            <Box textAlign={{ xs: "center", md: "left" }} mb={4}>
              <Typography variant="h5" fontWeight="bold" sx={{ fontSize: { xs: 20, md: 24 }, color: "#ffb347" }}>
                {modules[1].title}
              </Typography>
              <Typography variant="body1" sx={{ opacity: 0.9, fontSize: { xs: 14, md: 16 } }}>
                {modules[1].desc}
              </Typography>
            </Box>

            <Box textAlign={{ xs: "center", md: "left" }}>
              <Typography variant="h5" fontWeight="bold" sx={{ fontSize: { xs: 20, md: 24 }, color: "#ffb347" }}>
                {modules[3].title}
              </Typography>
              <Typography variant="body1" sx={{ opacity: 0.9, fontSize: { xs: 14, md: 16 } }}>
                {modules[3].desc}
              </Typography>
            </Box>
          </Grid>

        </Grid>

      </Container>

      {/* Industries Section */}
      <Box sx={{ mt: 8, overflow: "hidden" }}>
        <Box
          sx={{
            display: "flex",
            animation: "scroll 10s linear infinite",
            "@keyframes scroll": {
              "0%": { transform: "translateX(100%)" },
              "100%": { transform: "translateX(-100%)" }
            }
          }}
        >
          {[
              { name: "Manufacturing", icon: <FactoryIcon sx={{ fontSize: 40, color: "#000" }} /> },
              { name: "Healthcare", icon: <LocalHospitalIcon sx={{ fontSize: 40, color: "#000" }} /> },
              { name: "Education", icon: <SchoolIcon sx={{ fontSize: 40, color: "#000" }} /> },
              { name: "IT", icon: <DesktopWindowsIcon sx={{ fontSize: 40, color: "#000" }} /> },
              { name: "Banking", icon: <AccountBalanceIcon sx={{ fontSize: 40, color: "#000" }} /> }
          ].map((industry, index) => (
            <Box
              key={index}
              sx={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                mx: 4,
                minWidth: 200
              }}
            >
              <Typography variant="h6" sx={{ mr: 2, textAlign: "center", fontWeight: "bold", color: "#ffb347" }}>
                {industry.name}
              </Typography>
              {industry.icon}
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default HRMProcess;