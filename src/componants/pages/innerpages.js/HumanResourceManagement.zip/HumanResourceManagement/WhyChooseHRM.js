import React from "react";
import {
  Box,
  Typography,
  Container,
  Stack,
  Paper
} from "@mui/material";

import TuneIcon from "@mui/icons-material/Tune";
import SecurityIcon from "@mui/icons-material/Security";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import SupportAgentIcon from "@mui/icons-material/SupportAgent";

const features = [
  {
    icon: <TuneIcon />,
    title: "Customizable HRM Solutions"
  },
  {
    icon: <SecurityIcon />,
    title: "Secure Employee Data"
  },
  {
    icon: <TrendingUpIcon />,
    title: "Scalable HR Platform"
  },
  {
    icon: <SupportAgentIcon />,
    title: "24/7 Support"
  }
];

const WhyChooseHRM = () => {
  return (
    <Box
      sx={{
        background: "linear-gradient(45deg, #03228f, #93c0f8)",
        py: { xs: 4, md: 6 },
        color: "#000"
      }}
    >
      <Container maxWidth="md">

        {/* Title */}
        <Box textAlign="center" mb={5}>
          <Typography
            variant="h3"
            fontWeight="bold"
            sx={{
              mt: 1,
              fontSize: { xs: "26px", sm: "32px", md: "36px" }
            }}
          >
            Why Choose Our HRM Solutions
          </Typography>
        </Box>

        {/* Feature Cards */}
        <Stack spacing={2}>
          {features.map((item, index) => (
            <Paper
              key={index}
              elevation={0}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 2,
                px: 3,
                py: 2,
                borderRadius: 2,
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                backdropFilter: "blur(8px)"
              }}
            >
              <Box
                sx={{
                  color: "#000",
                  display: "flex",
                  alignItems: "center"
                }}
              >
                {item.icon}
              </Box>

              <Typography
                sx={{
                  fontSize: { xs: "14px", sm: "16px" },
                  color: "#fff"
                }}
              >
                {item.title}
              </Typography>
            </Paper>
          ))}
        </Stack>

      </Container>
    </Box>
  );
};

export default WhyChooseHRM;