import React from "react";
import {
    Box,
    Typography,
    Button,
    Grid,
    useTheme,
    useMediaQuery,
    Paper
} from "@mui/material";
import hrmBanner from "../../../../assets/hrm-banner.png";

const BannerSection = () => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
    const isTablet = useMediaQuery(theme.breakpoints.down("md"));

    return (
        <Box
            sx={{
                maxWidth: 1400,
                minHeight: "140vh",
                display: "flex",
                alignItems: "flex-start",   
                justifyContent: "center",   
                backgroundImage: `url(${hrmBanner})`,
                backgroundSize: "100% auto",
                backgroundPosition: "center bottom",
                backgroundRepeat: "no-repeat",
                color: "hsl(199, 94%, 76%)",
                px: { xs: 2, sm: 5, md: 10 },
                py: { xs: 4, md: 6 }
            }}
        >
            <Grid container spacing={6} alignItems="center" justifyContent="center">
                <Grid item xs={12} md={6}>
                    <Typography
                        variant={isMobile ? "h5" : "h4"}
                        fontWeight="bold"
                        sx={{
                            lineHeight: 1.3,
                            mb: 3,
                            textAlign: "center",
                            fontSize: { xs: 24, sm: 32, md: 38 }
                        }}
                    >
                        HUMAN RESOURCE MANAGEMENT SOFTWARE FOR SMALL BUSINESS IS NOW YOUR
                        GROWTH ENGINE
                    </Typography>

                    <Typography
                        variant="body2"
                        sx={{
                            opacity: 0.8,
                            mb: 4,
                            textAlign: "center"
                        }}
                    >
                        Engineering affordable human resource management software for
                        small business that suits unique local needs. Manage and track data
                        easily with bespoke HRM software solutions.
                    </Typography>

                    <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap", justifyContent: "center" }}>
                        <Button
                            variant="contained"
                            sx={{
                                background: "linear-gradient(45deg, #03228f, #93c0f8)",
                                px: 4,
                                py: 1.5,
                                borderRadius: "30px",
                                fontWeight: "bold"
                            }}
                        >
                            Request a demo
                        </Button>

                        <Button
                            variant="outlined"
                            sx={{
                                borderColor: "#ffb347",
                                color: "#ffb347",
                                px: 4,
                                py: 1.5,
                                borderRadius: "30px"
                            }}
                        >
                            Get Started
                        </Button>
                    </Box>
                </Grid>
            </Grid>
        </Box>
    );
};

export default BannerSection;