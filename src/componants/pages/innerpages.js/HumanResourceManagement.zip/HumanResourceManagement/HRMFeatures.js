import React from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Paper,
  Stack,
  useTheme,
  useMediaQuery
} from '@mui/material';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import FingerprintIcon from '@mui/icons-material/Fingerprint';
import FlightTakeoffIcon from '@mui/icons-material/FlightTakeoff';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import QueryStatsIcon from '@mui/icons-material/QueryStats';
import DonutLargeIcon from '@mui/icons-material/DonutLarge';

const glassStyle = {
  background: 'rgba(0, 0, 0, 0.03)',
  backdropFilter: 'blur(10px)',
  border: '1px solid rgba(0, 0, 0, 0.1)',
  borderRadius: '24px',
  padding: '32px',
  height: '100%',
  transition: 'transform 0.3s ease',
  '&:hover': {
    transform: 'translateY(-8px)',
    background: 'rgba(0, 0, 0, 0.06)',
  }
};

const HRMFeatures = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.down('md'));

  const features = [
    { title: 'Payroll', desc: 'Manage Indian local tax computations, PF, and ESIC compliance automatically.', icon: <AccountBalanceWalletIcon sx={{ fontSize: 40, color: '#000' }} /> },
    { title: 'Attendance', desc: 'Real-time biometric and geo-fencing integration for precise tracking.', icon: <FingerprintIcon sx={{ fontSize: 40, color: '#000' }} /> },
    { title: 'Leave', desc: 'Self-service portal for employees with integrated approval workflows.', icon: <FlightTakeoffIcon sx={{ fontSize: 40, color: '#000' }} /> },
    { title: 'Recruitment', desc: 'End-to-end applicant tracking system from job post to onboarding.', icon: <PersonSearchIcon sx={{ fontSize: 40, color: '#000' }} /> },
    { title: 'Performance', desc: 'Customizable goal-setting and continuous feedback loops.', icon: <DonutLargeIcon sx={{ fontSize: 40, color: '#000' }} /> },
    { title: 'Analytics', desc: 'Data-driven insights into workforce efficiency and turnover rates.', icon: <QueryStatsIcon sx={{ fontSize: 40, color: '#000' }} /> },
  ];

  return (
    <Box sx={{ background: "linear-gradient(45deg, #03228f, #93c0f8)", color: '#000', py: isMobile ? 6 : 10 }}>
      
      {/* SECTION 1: ABOUT HRM */}
      <Container maxWidth="md" sx={{ mb: isMobile ? 6 : 10, textAlign: 'center' }}>
        <Typography variant={isMobile ? "h4" : "h2"} sx={{ fontWeight: 800, mt: 2, mb: 3 }}>
          What is Human Resource Management Software?
        </Typography>
        <Typography variant="body1" sx={{ color: 'rgba(255,255,255,0.7)', fontSize: '1.1rem', lineHeight: 1.8 }}>
          Human Resource Management (HRM) software for small business is a digital solution 
          designed to manage employee data, recruitment, payroll, and performance. 
          Our human resource management software development focuses on automating tasks 
          to improve record accuracy and enhance workforce efficiency in one unified platform.
        </Typography>
      </Container>

      {/* SECTION 2: KEY FEATURES */}
      <Container maxWidth="lg">
        <Stack alignItems="center" sx={{ mb: 8 }}>
          <Typography variant={isMobile ? "h4" : "h3"} sx={{ fontWeight: 800, mt: 1, fontSize: { xs: "20px", sm: "24px", md: "28px" } }}>
            Key Features of Our HRM Software
          </Typography>
        </Stack>

        <Grid container rowSpacing={isMobile ? 8 : 12} columnSpacing={isMobile ? 3 : 4}>
          {features.map((item, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Paper elevation={0} sx={glassStyle}>
                <Box sx={{ mb: 2 }}>{item.icon}</Box>
                <Typography variant="h5" sx={{ fontWeight: 700, mb: 2 }}>
                  {item.title}
                </Typography>
                <Typography variant="body2" sx={{ color: 'rgba(255,255,255,0.6)', lineHeight: 1.6 }}>
                  {item.desc}
                </Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default HRMFeatures;