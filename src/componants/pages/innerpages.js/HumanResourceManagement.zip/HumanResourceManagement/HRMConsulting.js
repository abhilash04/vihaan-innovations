import React from "react";
import { Box, Typography, Button, Container } from "@mui/material";
import consultingBg from "../../../../assets/hrm-consulting.jpg";

const HRMConsultingSection = () => {
  return (
    <Box
      sx={{
        position: "relative",
        width: "100%",
        minHeight: { xs: "380px", sm: "420px", md: "480px" },
        backgroundImage: `url(${consultingBg})`,
        backgroundSize: "cover",
        backgroundPosition: "contain",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: "16px",
        overflow: "hidden"
      }}
    >
      {/* Dark overlay */}
      <Box
        sx={{
          position: "absolute",
          inset: 0,
          background: "rgba(0,0,0,0.55)"
        }}
      />

      {/* Content */}
      <Container
        sx={{
          position: "relative",
          textAlign: "center",
          color: "#fff",
          px: { xs: 2, sm: 4, md: 6 }
        }}
      >
        <Typography
          variant="h4"
          fontWeight="bold"
          sx={{
            fontSize: { xs: "22px", sm: "28px", md: "36px" },
            mb: 2
          }}
        >
          Scalable HRM Consulting Development Services
        </Typography>

        <Typography
          sx={{
            opacity: 0.9,
            maxWidth: "700px",
            mx: "auto",
            mb: 4,
            fontSize: { xs: "13px", sm: "15px", md: "16px" }
          }}
        >
          We develop custom, scalable HRM solutions. Covers API integrations,
          SaaS ERP, cloud-native applications, workforce automation, analytics,
          and reporting systems.
        </Typography>

        <Box
          sx={{
            display: "flex",
            gap: 2,
            justifyContent: "center",
            flexWrap: "wrap"
          }}
        >
          <Button
            variant="contained"
            sx={{
              background: "#ff8a00",
              borderRadius: "30px",
              px: 4,
              py: 1.3,
              fontWeight: "bold"
            }}
          >
            Request Consulting
          </Button>

          <Button
            variant="outlined"
            sx={{
              borderColor: "#fff",
              color: "#fff",
              borderRadius: "30px",
              px: 4,
              py: 1.3
            }}
          >
            See Case Studies
          </Button>
        </Box>
      </Container>
    </Box>
  );
};

export default HRMConsultingSection;