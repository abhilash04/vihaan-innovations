import { Grid } from "@mui/material";
import React from "react";
import Header from "../../../common/Header";
import HeaderSec from "../../../common/HeaderSec";
import FooterAndPopup from "../../../common/Footer";
import BannerSection from "./BannerSection";
import HRMBenefits from "./HRMBenifits";
import HRMFeatures from "./HRMFeatures";
import HRMConsultingSection from "./HRMConsulting";
import HRMProcess from "./HRMProcess";
import WhyChooseHRM from "./WhyChooseHRM";

const HumanResourceManagementHomePage = () => {
  return (
    <Grid>
        <Header />
        <HeaderSec />
        <BannerSection />
        <HRMBenefits />
        <HRMFeatures />
        <HRMConsultingSection />
        <HRMProcess />
        <WhyChooseHRM />
        <FooterAndPopup />
    </Grid>
  );
};

export default HumanResourceManagementHomePage;
