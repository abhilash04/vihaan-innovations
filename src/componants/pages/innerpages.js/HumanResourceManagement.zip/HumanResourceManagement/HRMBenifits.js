import React from "react";
import { Box, Container, Typography, Grid, Card, CardContent } from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import StorageIcon from "@mui/icons-material/Storage";
import PaymentsIcon from "@mui/icons-material/Payments";
import PeopleIcon from "@mui/icons-material/People";
import AssessmentIcon from "@mui/icons-material/Assessment";

const benefits = [
  {
    icon: <SettingsIcon sx={{ fontSize: 40, color: "#000" }} />,
    title: "Automate HR Processes"
  },
  {
    icon: <StorageIcon sx={{ fontSize: 40, color: "#000" }} />,
    title: "Improve Data Records"
  },
  {
    icon: <PaymentsIcon sx={{ fontSize: 40, color: "#000" }} />,
    title: "Enhance Payroll Accuracy"
  },
  {
    icon: <PeopleIcon sx={{ fontSize: 40, color: "#000" }} />,
    title: "Improve Workforce Management"
  },
  {
    icon: <AssessmentIcon sx={{ fontSize: 40, color: "#000" }} />,
    title: "Insightful HR Reports"
  }
];

const HRMBenefits = () => {
  return (
    <Box
      sx={{
        background: "linear-gradient(45deg, #03228f, #93c0f8)",
        color: "#000",
        py: { xs: 4, sm: 6, md: 8 }
      }}
    >
      <Container maxWidth="lg">
        <Box textAlign="center" mb={6}>
          <Typography
            variant="h3"
            fontWeight="bold"
            sx={{
              mt: 0,
              fontSize: { xs: "24px", sm: "30px", md: "36px" }
            }}
          >
            Benefits of Using HRM Systems
          </Typography>

          <Typography
            variant="body1"
            sx={{
              opacity: 0.8,
              mt: 2,
              maxWidth: 700,
              mx: "auto",
              fontSize: { xs: "14px", sm: "16px" }
            }}
          >
            Human Resource Management (HRM) software is a digital solution
            designed to manage employee data, payroll, and performance. It
            enhances productivity, improves records accuracy, and streamlines
            workforce management in a unified platform.
          </Typography>
        </Box>

        {/* Benefits Grid */}
        <Grid container spacing={4} justifyContent="center">
          {benefits.map((item, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card
                sx={{
                  height: "100%",
                  background: "transparent",
                  color: "#000",
                  textAlign: "center",
                  transition: "transform 0.3s ease, background 0.3s ease",
                  "&:hover": {
                    transform: "translateY(-5px)",
                    background: "rgba(0,0,0,0.1)"
                  },
                  boxShadow: "none"
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      mb: 2
                    }}
                  >
                    {item.icon}
                  </Box>

                  <Typography
                    variant="h6"
                    fontWeight="500"
                    sx={{
                      fontSize: { xs: "14px", sm: "16px" }
                    }}
                  >
                    {item.title}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default HRMBenefits;